package com.blinkscroll.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blinkscroll.app.data.BlinkSettings
import com.blinkscroll.app.ui.theme.AccentCyan
import com.blinkscroll.app.ui.theme.DarkSurfaceCard

/**
 * Layar Pengaturan untuk mengatur parameter sensitivitas, durasi, dan swipe gesture.
 * Perubahan nilai langsung disimpan ke DataStore dan di-observe tanpa perlu restart service.
 */
@Composable
fun SettingsScreen(
    settings: BlinkSettings,
    onUpdateCloseThreshold: (Float) -> Unit,
    onUpdateMinLongBlink: (Long) -> Unit,
    onUpdateScrollDistance: (Int) -> Unit,
    onUpdateCooldown: (Long) -> Unit,
    onUpdateAutoStop: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Pengaturan Deteksi & Gesture",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        // 1. Sensitivitas Tutup Mata (CLOSE_THRESHOLD)
        SettingSliderCard(
            title = "Sensitivitas Tutup Mata (CLOSE_THRESHOLD)",
            description = "Nilai skor MediaPipe untuk mengenali mata tertutup (default 0.60). Turunkan jika mata Anda sipit.",
            valueText = String.format("%.2f", settings.closeThreshold),
            value = settings.closeThreshold,
            valueRange = 0.40f..0.80f,
            steps = 8,
            onValueChange = onUpdateCloseThreshold
        )

        // 2. Durasi Kedip Panjang Minimum
        SettingSliderCard(
            title = "Durasi Kedip Panjang Minimum (Scroll Turun)",
            description = "Waktu mata harus ditahan tertutup untuk memicu scroll ke bawah (default 500 ms).",
            valueText = "${settings.minLongBlinkMs} ms",
            value = settings.minLongBlinkMs.toFloat(),
            valueRange = 400f..900f,
            steps = 10,
            onValueChange = { onUpdateMinLongBlink(it.toLong()) }
        )

        // 3. Jarak Scroll (% Layar)
        SettingSliderCard(
            title = "Jarak Scroll Layar (Panjang Usapan)",
            description = "Persentase tinggi layar yang diusap setiap kali aksi kedipan terpicu (default 40%).",
            valueText = "${settings.scrollDistancePercent}%",
            value = settings.scrollDistancePercent.toFloat(),
            valueRange = 25f..60f,
            steps = 7,
            onValueChange = { onUpdateScrollDistance(it.toInt()) }
        )

        // 4. Cooldown Jeda Antar Aksi
        SettingSliderCard(
            title = "Cooldown Jeda Antar Aksi",
            description = "Waktu istirahat setelah scroll sebelum menerima kedipan berikutnya guna mencegah trigger ganda.",
            valueText = "${settings.cooldownMs} ms",
            value = settings.cooldownMs.toFloat(),
            valueRange = 500f..2000f,
            steps = 15,
            onValueChange = { onUpdateCooldown(it.toLong()) }
        )

        // 5. Auto-Stop Waktu Mati Otomatis
        SettingSliderCard(
            title = "Auto-Stop Layanan (Hemat Baterai)",
            description = "Otomatis menghentikan kamera jika tidak ada interaksi selama periode tertentu.",
            valueText = "${settings.autoStopMinutes} Menit",
            value = settings.autoStopMinutes.toFloat(),
            valueRange = 10f..60f,
            steps = 5,
            onValueChange = { onUpdateAutoStop(it.toInt()) }
        )
    }
}

@Composable
private fun SettingSliderCard(
    title: String,
    description: String,
    valueText: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    steps: Int = 0,
    onValueChange: (Float) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = valueText,
                    fontWeight = FontWeight.Bold,
                    color = AccentCyan,
                    fontSize = 14.sp
                )
            }

            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = Color.LightGray
            )

            Slider(
                value = value,
                onValueChange = onValueChange,
                valueRange = valueRange,
                steps = steps,
                colors = SliderDefaults.colors(
                    thumbColor = AccentCyan,
                    activeTrackColor = AccentCyan
                )
            )
        }
    }
}
