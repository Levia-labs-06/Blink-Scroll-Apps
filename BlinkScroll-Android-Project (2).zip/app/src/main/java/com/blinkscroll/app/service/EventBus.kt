package com.blinkscroll.app.service

import com.blinkscroll.app.model.BlinkEvent
import com.blinkscroll.app.model.CalibrationTelemetry
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * EventBus Singleton untuk komunikasi terisolasi antar komponen:
 * CameraForegroundService -> ScrollAccessibilityService & MainActivity (Compose).
 */
object EventBus {

    // Aliran event kedipan mata (replay = 0 agar hanya memproses event yang baru terjadi)
    private val _blinkEvents = MutableSharedFlow<BlinkEvent>(extraBufferCapacity = 16)
    val blinkEvents: SharedFlow<BlinkEvent> = _blinkEvents.asSharedFlow()

    // Status telemetri kalibrasi real-time untuk layar uji coba di MainActivity
    private val _telemetry = MutableStateFlow(CalibrationTelemetry())
    val telemetry: StateFlow<CalibrationTelemetry> = _telemetry.asStateFlow()

    // Status hidup/mati dari Foreground Service
    private val _isServiceRunning = MutableStateFlow(false)
    val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

    // Status koneksi Layanan Aksesibilitas
    private val _isAccessibilityConnected = MutableStateFlow(false)
    val isAccessibilityConnected: StateFlow<Boolean> = _isAccessibilityConnected.asStateFlow()

    suspend fun emitBlinkEvent(event: BlinkEvent) {
        _blinkEvents.emit(event)
    }

    fun tryEmitBlinkEvent(event: BlinkEvent): Boolean {
        return _blinkEvents.tryEmit(event)
    }

    fun updateTelemetry(telemetry: CalibrationTelemetry) {
        _telemetry.value = telemetry
    }

    fun setServiceRunning(running: Boolean) {
        _isServiceRunning.value = running
    }

    fun setAccessibilityConnected(connected: Boolean) {
        _isAccessibilityConnected.value = connected
    }
}
