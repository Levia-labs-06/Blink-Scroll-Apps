package com.blinkscroll.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blinkscroll.app.ui.theme.AccentGreen
import com.blinkscroll.app.ui.theme.AccentRed
import com.blinkscroll.app.ui.theme.DarkSurfaceCard

/**
 * Kartu Wizard Izin Berurutan untuk memastikan pengguna mengaktifkan semua izin:
 * 1. Izin Kamera (Untuk deteksi mata MediaPipe)
 * 2. Izin Notifikasi (Android 13+ untuk Foreground Service)
 * 3. Layanan Aksesibilitas (Untuk mengeksekusi gesture scroll di atas aplikasi lain)
 */
@Composable
fun PermissionWizard(
    hasCameraPermission: Boolean,
    hasNotificationPermission: Boolean,
    hasAccessibilityPermission: Boolean,
    onRequestCamera: () -> Unit,
    onRequestNotification: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Pemeriksaan Izin Sistem",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Text(
                text = "BlinkScroll memerlukan ketiga izin di bawah ini agar dapat mendeteksi kedipan mata dan mengusap layar di atas aplikasi lain.",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.LightGray
            )

            // Step 1: Kamera
            PermissionItem(
                stepNumber = "1",
                title = "Izin Kamera Depan",
                description = "Mendeteksi kedipan mata lokal secara real-time",
                isGranted = hasCameraPermission,
                actionLabel = "Izinkan Kamera",
                onAction = onRequestCamera
            )

            Divider(color = Color.DarkGray.copy(alpha = 0.5f))

            // Step 2: Notifikasi
            PermissionItem(
                stepNumber = "2",
                title = "Izin Notifikasi",
                description = "Menjaga proses kamera tetap berjalan di background",
                isGranted = hasNotificationPermission,
                actionLabel = "Izinkan Notifikasi",
                onAction = onRequestNotification
            )

            Divider(color = Color.DarkGray.copy(alpha = 0.5f))

            // Step 3: Layanan Aksesibilitas
            PermissionItem(
                stepNumber = "3",
                title = "Layanan Aksesibilitas",
                description = "Mengizinkan usapan scroll otomatis pada layar aktif",
                isGranted = hasAccessibilityPermission,
                actionLabel = "Buka Pengaturan Aksesibilitas",
                onAction = onOpenAccessibilitySettings
            )
        }
    }
}

@Composable
private fun PermissionItem(
    stepNumber: String,
    title: String,
    description: String,
    isGranted: Boolean,
    actionLabel: String,
    onAction: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Lingkaran Status / Centang
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(if (isGranted) AccentGreen.copy(alpha = 0.2f) else AccentRed.copy(alpha = 0.2f))
                .border(
                    width = 1.dp,
                    color = if (isGranted) AccentGreen else AccentRed,
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isGranted) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Diizinkan",
                    tint = AccentGreen,
                    modifier = Modifier.size(18.dp)
                )
            } else {
                Text(
                    text = stepNumber,
                    color = AccentRed,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }

        // Teks Deskripsi
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }

        // Tombol Aksi jika belum aktif
        if (!isGranted) {
            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.Black
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(text = "Aktifkan", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
