package com.blinkscroll.app.model

/**
 * Tipe aksi kedipan mata yang terdeteksi secara sengaja.
 */
enum class BlinkAction {
    /**
     * Kedipan panjang (tahan tutup mata) -> Memicu scroll ke BAWAH.
     */
    LONG_BLINK,

    /**
     * Dua kedipan cepat berurutan -> Memicu scroll ke ATAS.
     */
    DOUBLE_BLINK
}

/**
 * Model data event kedipan yang dikirimkan melalui EventBus.
 */
data class BlinkEvent(
    val action: BlinkAction,
    val timestamp: Long = System.currentTimeMillis(),
    val durationMs: Long = 0L,
    val description: String = ""
)

/**
 * Status telemetri kalibrasi real-time dari MediaPipe untuk ditampilkan di UI.
 */
data class CalibrationTelemetry(
    val leftBlinkScore: Float = 0f,
    val rightBlinkScore: Float = 0f,
    val averageScore: Float = 0f,
    val isEyesClosed: Boolean = false,
    val faceDetected: Boolean = false,
    val fps: Float = 0f,
    val lastEvent: BlinkEvent? = null
)
