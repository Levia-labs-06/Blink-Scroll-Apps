package com.blinkscroll.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blinkscroll.app.ui.components.PermissionWizard
import com.blinkscroll.app.ui.theme.AccentCyan
import com.blinkscroll.app.ui.theme.AccentGreen
import com.blinkscroll.app.ui.theme.AccentRed
import com.blinkscroll.app.ui.theme.DarkSurfaceCard

/**
 * Layar Beranda BlinkScroll:
 * - Menampilkan status izin via PermissionWizard.
 * - Tombol Start/Stop Service utama (hanya aktif jika semua izin siap).
 * - Panduan gestur kedipan (Long Blink vs Double Blink).
 */
@Composable
fun HomeScreen(
    isServiceRunning: Boolean,
    hasCameraPermission: Boolean,
    hasNotificationPermission: Boolean,
    hasAccessibilityPermission: Boolean,
    onRequestCamera: () -> Unit,
    onRequestNotification: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onToggleService: () -> Unit,
    onNavigateCalibration: () -> Unit,
    modifier: Modifier = Modifier
) {
    val allPermissionsReady = hasCameraPermission && hasNotificationPermission && hasAccessibilityPermission
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Kartu Status Layanan Utama
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isServiceRunning) AccentGreen.copy(alpha = 0.15f) else DarkSurfaceCard
            ),
            border = if (isServiceRunning) CardDefaults.outlinedCardBorder().copy(
                brush = androidx.compose.ui.graphics.SolidColor(AccentGreen)
            ) else null
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(if (isServiceRunning) AccentGreen else Color.DarkGray),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isServiceRunning) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                        contentDescription = "Status",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Text(
                    text = if (isServiceRunning) "BlinkScroll SEDANG AKTIF" else "BlinkScroll Tidak Aktif",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = if (isServiceRunning) AccentGreen else Color.White
                )

                Text(
                    text = if (isServiceRunning)
                        "Kamera depan sedang memantau kedipan di latar belakang. Anda dapat membuka aplikasi lain dan berkedip untuk menggulir layar."
                    else
                        "Pastikan seluruh izin terpenuhi, lalu tekan tombol Mulai di bawah ini.",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    color = Color.LightGray
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Tombol Utama Mulai / Berhenti
                Button(
                    onClick = onToggleService,
                    enabled = allPermissionsReady || isServiceRunning,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isServiceRunning) AccentRed else MaterialTheme.colorScheme.primary,
                        contentColor = if (isServiceRunning) Color.White else Color.Black
                    )
                ) {
                    Icon(
                        imageVector = if (isServiceRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isServiceRunning) "Hentikan Layanan" else "Mulai BlinkScroll",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Tampilkan Wizard Izin jika belum lengkap
        AnimatedVisibility(visible = !allPermissionsReady) {
            PermissionWizard(
                hasCameraPermission = hasCameraPermission,
                hasNotificationPermission = hasNotificationPermission,
                hasAccessibilityPermission = hasAccessibilityPermission,
                onRequestCamera = onRequestCamera,
                onRequestNotification = onRequestNotification,
                onOpenAccessibilitySettings = onOpenAccessibilitySettings
            )
        }

        // Tombol Shortcut ke Layar Kalibrasi
        OutlinedButton(
            onClick = onNavigateCalibration,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentCyan)
        ) {
            Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Buka Layar Kalibrasi Skor Mata", fontWeight = FontWeight.SemiBold)
        }

        // Panduan Penggunaan Gestur Kedipan
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Panduan Kedipan Mata Sengaja",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                GestureGuideRow(
                    title = "Kedip Panjang (Tahan ~0.5 - 1.2 detik)",
                    description = "Scroll ke BAWAH pada aplikasi yang aktif",
                    icon = Icons.Default.ArrowDownward,
                    accentColor = AccentCyan
                )

                Divider(color = Color.DarkGray.copy(alpha = 0.5f))

                GestureGuideRow(
                    title = "Kedip Dobel (2x Cepat dalam 0.6 detik)",
                    description = "Scroll ke ATAS pada aplikasi yang aktif",
                    icon = Icons.Default.ArrowUpward,
                    accentColor = MaterialTheme.colorScheme.primary
                )

                Divider(color = Color.DarkGray.copy(alpha = 0.5f))

                GestureGuideRow(
                    title = "Kedip Alami (100 - 400 ms)",
                    description = "Diabaikan otomatis agar tidak mengganggu scroll normal",
                    icon = Icons.Default.Block,
                    accentColor = Color.Gray
                )
            }
        }
    }
}

@Composable
private fun GestureGuideRow(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(accentColor.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = accentColor)
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = Color.LightGray
            )
        }
    }
}
