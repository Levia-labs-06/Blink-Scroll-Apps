package com.blinkscroll.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.KeyguardManager
import android.content.Context
import android.graphics.Path
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import com.blinkscroll.app.data.PreferencesRepository
import com.blinkscroll.app.model.BlinkAction
import com.blinkscroll.app.model.BlinkEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * ScrollAccessibilityService: Melakukan injeksi gesture usapan vertikal (dispatchGesture)
 * pada aplikasi yang sedang aktif di layar pengguna.
 */
class ScrollAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "ScrollAccessibility"
        private const val GESTURE_DURATION_MS = 250L
    }

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var preferencesRepo: PreferencesRepository
    private var scrollDistancePercent: Int = 40

    private var vibrator: Vibrator? = null
    private var keyguardManager: KeyguardManager? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "ScrollAccessibilityService terhubung dan siap")
        EventBus.setAccessibilityConnected(true)

        preferencesRepo = PreferencesRepository(applicationContext)
        keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager

        // Inisialisasi Vibrator untuk Haptic Feedback
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

        // Amati perubahan pengaturan jarak scroll
        serviceScope.launch {
            preferencesRepo.settingsFlow.collectLatest { settings ->
                scrollDistancePercent = settings.scrollDistancePercent
            }
        }

        // Amati event kedipan dari EventBus
        serviceScope.launch {
            EventBus.blinkEvents.collect { blinkEvent ->
                handleBlinkEvent(blinkEvent)
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Tidak perlu memproses event pohon aksesibilitas karena kita berfokus pada gesture
    }

    override fun onInterrupt() {
        Log.d(TAG, "ScrollAccessibilityService diinterupsi")
    }

    /**
     * Memproses event kedipan yang masuk:
     * - Cek apakah keyboard/IME aktif atau layar sedang terkunci.
     * - Jalankan gesture swipe vertikal dan getaran haptic singkat.
     */
    private fun handleBlinkEvent(event: BlinkEvent) {
        // 1. Jangan lakukan scroll jika layar sedang terkunci (Keyguard aktif)
        if (keyguardManager?.isKeyguardLocked == true) {
            Log.d(TAG, "Aksi diabaikan: Perangkat sedang terkunci (Keyguard active)")
            return
        }

        // 2. Jangan lakukan scroll jika keyboard virtual (Input Method) sedang aktif di layar
        if (isKeyboardOpen()) {
            Log.d(TAG, "Aksi diabaikan: Keyboard virtual sedang terbuka")
            return
        }

        // 3. Ambil dimensi layar aktif dari WindowMetrics / DisplayMetrics
        val (screenWidth, screenHeight) = getScreenDimensions()
        val centerX = screenWidth / 2f
        val distancePx = screenHeight * (scrollDistancePercent / 100f)

        // Tentukan titik awal dan akhir swipe
        val startY: Float
        val endY: Float

        when (event.action) {
            BlinkAction.LONG_BLINK -> {
                // Scroll Turun: Swipe jari dari bawah ke atas
                startY = (screenHeight * 0.70f)
                endY = (startY - distancePx).coerceAtLeast(screenHeight * 0.15f)
            }
            BlinkAction.DOUBLE_BLINK -> {
                // Scroll Naik: Swipe jari dari atas ke bawah
                startY = (screenHeight * 0.30f)
                endY = (startY + distancePx).coerceAtMost(screenHeight * 0.85f)
            }
        }

        performSwipe(centerX, startY, centerX, endY)
        playHapticFeedback()
    }

    /**
     * Mengirimkan gesture usapan menggunakan dispatchGesture().
     */
    private fun performSwipe(startX: Float, startY: Float, endX: Float, endY: Float) {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }

        val stroke = GestureDescription.StrokeDescription(
            path,
            0L,
            GESTURE_DURATION_MS
        )

        val gesture = GestureDescription.Builder()
            .addStroke(stroke)
            .build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                Log.d(TAG, "Gesture usapan berhasil dieksekusi")
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                super.onCancelled(gestureDescription)
                Log.w(TAG, "Gesture usapan dibatalkan oleh sistem")
            }
        }, null)
    }

    /**
     * Memeriksa apakah keyboard virtual (IME) sedang terbuka pada jendela aktif.
     */
    private fun isKeyboardOpen(): Boolean {
        try {
            val windows = windows
            for (window in windows) {
                if (window.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) {
                    return true
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error saat memeriksa status keyboard: ${e.message}")
        }
        return false
    }

    /**
     * Mendapatkan ukuran lebar dan tinggi layar secara dinamis.
     */
    private fun getScreenDimensions(): Pair<Int, Int> {
        val metrics = resources.displayMetrics
        return Pair(metrics.widthPixels, metrics.heightPixels)
    }

    /**
     * Memberikan umpan balik getaran singkat (haptic) agar pengguna tahu aksinya berhasil.
     */
    private fun playHapticFeedback() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(35L, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(35L)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Gagal memutar haptic feedback: ${e.message}")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.setAccessibilityConnected(false)
        serviceScope.cancel()
        Log.d(TAG, "ScrollAccessibilityService dihancurkan")
    }
}
