package com.blinkscroll.app.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blinkscroll.app.data.BlinkSettings
import com.blinkscroll.app.model.CalibrationTelemetry
import com.blinkscroll.app.ui.theme.AccentCyan
import com.blinkscroll.app.ui.theme.AccentGreen
import com.blinkscroll.app.ui.theme.AccentRed
import com.blinkscroll.app.ui.theme.DarkSurfaceCard

/**
 * Layar Kalibrasi Real-time:
 * - Menampilkan skor blendshape mata kiri & kanan (0.0 - 1.0).
 * - Visual bar dengan garis batas CLOSE_THRESHOLD.
 * - Indikator wajah terdeteksi dan frame rate (FPS).
 * - Riwayat / log event aksi terakhir.
 */
@Composable
fun CalibrationScreen(
    telemetry: CalibrationTelemetry,
    settings: BlinkSettings,
    isServiceRunning: Boolean,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    val eyeBoxColor by animateColorAsState(
        targetValue = if (telemetry.isEyesClosed) AccentRed else AccentGreen,
        label = "eyeColor"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (!isServiceRunning) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = AccentRed.copy(alpha = 0.15f))
            ) {
                Text(
                    text = "Layanan kamera belum aktif. Nyalakan layanan di Beranda terlebih dahulu untuk melihat telemetri mata secara langsung.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = AccentRed,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }

        // Kartu Status Deteksi Real-Time
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Telemetri MediaPipe",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(if (telemetry.faceDetected) AccentGreen else AccentRed)
                        )
                        Text(
                            text = if (telemetry.faceDetected) "Wajah Terdeteksi" else "Wajah Tidak Ada",
                            fontSize = 12.sp,
                            color = if (telemetry.faceDetected) AccentGreen else AccentRed
                        )
                        Text(
                            text = "(${String.format("%.1f", telemetry.fps)} FPS)",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                }

                // Skor Rata-Rata Kedipan Mata
                Text(
                    text = "Skor Rata-rata Kedipan: ${String.format("%.2f", telemetry.averageScore)} (Threshold Tutup: ${settings.closeThreshold})",
                    fontSize = 13.sp,
                    color = Color.LightGray
                )

                LinearProgressIndicator(
                    progress = { telemetry.averageScore.coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(14.dp)
                        .clip(RoundedCornerShape(7.dp)),
                    color = eyeBoxColor,
                    trackColor = Color.DarkGray
                )

                // Indikator Mata Kiri & Kanan Terpisah
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    EyeMeterColumn(
                        label = "Mata Kiri",
                        score = telemetry.leftBlinkScore,
                        modifier = Modifier.weight(1f)
                    )
                    EyeMeterColumn(
                        label = "Mata Kanan",
                        score = telemetry.rightBlinkScore,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Visual Status Tutup / Buka
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(eyeBoxColor.copy(alpha = 0.2f))
                        .border(1.dp, eyeBoxColor, RoundedCornerShape(10.dp))
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (telemetry.isEyesClosed) "STATUS: MATA TERTUTUP" else "STATUS: MATA TERBUKA",
                        fontWeight = FontWeight.Bold,
                        color = eyeBoxColor,
                        fontSize = 14.sp
                    )
                }
            }
        }

        // Kartu Log Event Terakhir
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Log Aksi Terakhir",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                val lastEvent = telemetry.lastEvent
                if (lastEvent != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(AccentCyan.copy(alpha = 0.15f))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(
                                text = "Aksi: ${lastEvent.action.name}",
                                fontWeight = FontWeight.Bold,
                                color = AccentCyan
                            )
                            Text(
                                text = lastEvent.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White
                            )
                            Text(
                                text = "Waktu: ${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(lastEvent.timestamp))}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.Gray
                            )
                        }
                    }
                } else {
                    Text(
                        text = "Belum ada event kedipan sengaja yang terdeteksi. Coba tahan kedip mata Anda selama ${settings.minLongBlinkMs} ms untuk menguji.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
            }
        }
    }
}

@Composable
private fun EyeMeterColumn(
    label: String,
    score: Float,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color.Black.copy(alpha = 0.25f))
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(text = label, fontSize = 12.sp, color = Color.Gray)
        Text(
            text = String.format("%.2f", score),
            fontWeight = FontWeight.Bold,
            color = Color.White,
            fontSize = 16.sp
        )
        LinearProgressIndicator(
            progress = { score.coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = AccentCyan,
            trackColor = Color.DarkGray
        )
    }
}
