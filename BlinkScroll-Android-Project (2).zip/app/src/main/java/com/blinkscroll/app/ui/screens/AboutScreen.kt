package com.blinkscroll.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blinkscroll.app.ui.theme.AccentCyan
import com.blinkscroll.app.ui.theme.AccentGreen
import com.blinkscroll.app.ui.theme.DarkSurfaceCard

/**
 * Layar Informasi Aplikasi dan Pernyataan Privasi:
 * Menjelaskan bahwa seluruh pemrosesan frame kamera dilakukan secara lokal di perangkat
 * menggunakan model Google MediaPipe Tasks Vision tanpa pernah menyimpan frame ke disk atau internet.
 */
@Composable
fun AboutScreen(
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Tentang & Kebijakan Privasi",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                PrivacyFeatureItem(
                    icon = Icons.Default.Lock,
                    title = "100% Pemrosesan On-Device",
                    description = "Semua frame kamera diproses langsung di memori RAM oleh model Google MediaPipe. Tidak ada foto, video, atau rekaman wajah yang disimpan ke penyimpanan ponsel."
                )

                Divider(color = Color.DarkGray.copy(alpha = 0.5f))

                PrivacyFeatureItem(
                    icon = Icons.Default.Security,
                    title = "Tanpa Akses Internet",
                    description = "Aplikasi ini tidak memiliki izin INTERNET di AndroidManifest. Data biometrik Anda tidak akan pernah dikirim ke server mana pun."
                )

                Divider(color = Color.DarkGray.copy(alpha = 0.5f))

                PrivacyFeatureItem(
                    icon = Icons.Default.Speed,
                    title = "Efisien & Ramah Baterai",
                    description = "Resolusi kamera dipatok pada 320x240 (~15 fps) dengan auto-pause saat layar mati (ACTION_SCREEN_OFF) guna menjaga suhu dan baterai perangkat tetap awet."
                )
            }
        }

        // Info Versi & Lisensi
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "BlinkScroll v1.0.0",
                    fontWeight = FontWeight.Bold,
                    color = AccentCyan,
                    fontSize = 16.sp
                )
                Text(
                    text = "Aplikasi Aksesibilitas Hands-Free untuk Android 9 (API 28) hingga Android 14 (API 34).",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.LightGray
                )
                Text(
                    text = "Ditenagai oleh Jetpack Compose, CameraX, dan Google MediaPipe Tasks Vision.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }
        }
    }
}

@Composable
private fun PrivacyFeatureItem(
    icon: ImageVector,
    title: String,
    description: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(AccentGreen.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = AccentGreen)
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = Color.LightGray,
                lineHeight = 18.sp
            )
        }
    }
}
