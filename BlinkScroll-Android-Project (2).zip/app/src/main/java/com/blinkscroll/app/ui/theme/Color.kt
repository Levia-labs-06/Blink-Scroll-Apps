package com.blinkscroll.app.ui.theme

import androidx.compose.ui.graphics.Color

val Teal80 = Color(0xFF2DD4BF)
val TealGrey80 = Color(0xFFA5F3FC)
val Cyan80 = Color(0xFF67E8F9)

val Teal40 = Color(0xFF0D9488)
val TealDark = Color(0xFF0F766E)
val Cyan40 = Color(0xFF0891B2)

val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF131B2E)
val DarkSurfaceCard = Color(0xFF1E293B)
val AccentCyan = Color(0xFF06B6D4)
val AccentGreen = Color(0xFF10B981)
val AccentAmber = Color(0xFFF59E0B)
val AccentRed = Color(0xFFEF4444)
