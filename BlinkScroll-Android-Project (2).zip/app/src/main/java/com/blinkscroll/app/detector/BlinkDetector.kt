package com.blinkscroll.app.detector

import com.blinkscroll.app.data.BlinkSettings
import com.blinkscroll.app.model.BlinkAction
import com.blinkscroll.app.model.BlinkEvent

/**
 * Status mata dalam state machine.
 */
enum class EyeState {
    OPEN,
    CLOSING
}

/**
 * BlinkDetector: Kelas murni Kotlin yang mengevaluasi deretan skor kedipan mata.
 *
 * Logika state machine:
 * 1. OPEN -> CLOSING saat skor rata-rata >= CLOSE_THRESHOLD. Catat waktu mulai tutup.
 * 2. CLOSING -> OPEN saat skor rata-rata <= OPEN_THRESHOLD. Hitung durasi tutup mata:
 *    - Durasi < 80 ms: Noise / glitch (diabaikan)
 *    - Durasi 100 - 400 ms: Kedip alami biologis (15-20x/menit, diabaikan)
 *    - Durasi >= minLongBlinkMs: LONG_BLINK (scroll turun)
 *    - Jika dua kedip pendek terjadi berturutan dalam waktu <= doubleBlinkWindowMs: DOUBLE_BLINK (scroll naik)
 * 3. Cooldown diterapkan setelah aksi berhasil dipicu untuk mencegah spam/trigger ganda.
 * 4. Jika wajah hilang > 2 detik, state detector direset otomatis.
 */
class BlinkDetector(
    var settings: BlinkSettings = BlinkSettings()
) {
    private var currentState: EyeState = EyeState.OPEN
    private var eyeCloseStartTimeMs: Long = 0L

    // Menyimpan waktu kedip pendek sebelumnya untuk mendeteksi double-blink
    private var lastShortBlinkEndTimeMs: Long = 0L

    // Waktu eksekusi aksi terakhir untuk menghitung cooldown
    private var lastActionExecutionTimeMs: Long = 0L

    // Timestamp deteksi wajah terakhir untuk mendeteksi timeout
    private var lastFaceTimestampMs: Long = 0L

    /**
     * Memproses satu frame skor kedipan.
     *
     * @param leftBlink Skor blendshape eyeBlinkLeft (0.0f - 1.0f)
     * @param rightBlink Skor blendshape eyeBlinkRight (0.0f - 1.0f)
     * @param currentTimeMs Waktu sekarang dalam milidetik (dapat di-inject untuk unit testing)
     * @return BlinkEvent jika aksi sengaja terdeteksi, atau null jika tidak ada aksi
     */
    fun processFrame(
        leftBlink: Float,
        rightBlink: Float,
        currentTimeMs: Long = System.currentTimeMillis()
    ): BlinkEvent? {
        lastFaceTimestampMs = currentTimeMs
        val avgScore = (leftBlink + rightBlink) / 2.0f

        when (currentState) {
            EyeState.OPEN -> {
                // Mata terdeteksi mulai menutup jika melampaui CLOSE_THRESHOLD
                if (avgScore >= settings.closeThreshold) {
                    currentState = EyeState.CLOSING
                    eyeCloseStartTimeMs = currentTimeMs
                }
            }

            EyeState.CLOSING -> {
                // Mata terdeteksi sudah terbuka kembali jika turun di bawah OPEN_THRESHOLD (histeresis)
                if (avgScore <= settings.openThreshold) {
                    currentState = EyeState.OPEN
                    val duration = currentTimeMs - eyeCloseStartTimeMs

                    // Cek apakah masih dalam periode cooldown setelah aksi terakhir
                    val isInCooldown = (currentTimeMs - lastActionExecutionTimeMs) < settings.cooldownMs

                    if (isInCooldown) {
                        // Abaikan selama masa cooldown
                        return null
                    }

                    // Skenario 1: Kedipan Panjang (Sengaja ditahan)
                    if (duration >= settings.minLongBlinkMs && duration <= settings.maxLongBlinkMs) {
                        lastActionExecutionTimeMs = currentTimeMs
                        lastShortBlinkEndTimeMs = 0L // Reset memori kedipan pendek
                        return BlinkEvent(
                            action = BlinkAction.LONG_BLINK,
                            timestamp = currentTimeMs,
                            durationMs = duration,
                            description = "Kedip Panjang ($duration ms) -> Scroll Turun"
                        )
                    }

                    // Skenario 2: Kedipan Cepat (Bisa jadi kedip alami atau bagian dari Double Blink)
                    if (duration in 80L..380L) {
                        val timeSinceLastShortBlink = currentTimeMs - lastShortBlinkEndTimeMs

                        if (lastShortBlinkEndTimeMs > 0L && timeSinceLastShortBlink <= settings.doubleBlinkWindowMs) {
                            // Dua kedipan cepat dalam rentang waktu yang diizinkan -> DOUBLE_BLINK
                            lastActionExecutionTimeMs = currentTimeMs
                            lastShortBlinkEndTimeMs = 0L // Reset setelah memicu
                            return BlinkEvent(
                                action = BlinkAction.DOUBLE_BLINK,
                                timestamp = currentTimeMs,
                                durationMs = duration,
                                description = "Kedip Dobel (jeda $timeSinceLastShortBlink ms) -> Scroll Naik"
                            )
                        } else {
                            // Kedipan cepat pertama (atau kedip alami) -> simpan waktu untuk menunggu potensi kedip kedua
                            lastShortBlinkEndTimeMs = currentTimeMs
                        }
                    }
                }
            }
        }

        return null
    }

    /**
     * Memeriksa apakah wajah telah hilang lebih dari ambang batas (default 2 detik).
     * Jika wajah hilang, reset state untuk mencegah false trigger saat wajah muncul lagi.
     */
    fun checkFaceTimeout(currentTimeMs: Long = System.currentTimeMillis()) {
        if (lastFaceTimestampMs > 0L && (currentTimeMs - lastFaceTimestampMs) > 2000L) {
            reset()
        }
    }

    /**
     * Reset seluruh state detector ke kondisi awal.
     */
    fun reset() {
        currentState = EyeState.OPEN
        eyeCloseStartTimeMs = 0L
        lastShortBlinkEndTimeMs = 0L
        lastFaceTimestampMs = 0L
    }

    /**
     * Mendapatkan status mata saat ini.
     */
    fun isEyesClosed(): Boolean = currentState == EyeState.CLOSING
}
