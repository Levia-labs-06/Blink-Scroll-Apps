package com.blinkscroll.app.service

import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.core.content.ContextCompat
import com.blinkscroll.app.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Quick Settings Tile untuk mempermudah pengguna menyalakan dan mematikan
 * BlinkScroll langsung dari status bar / notification shade Android.
 */
class BlinkTileService : TileService() {

    private val tileScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onStartListening() {
        super.onStartListening()
        updateTileState(EventBus.isServiceRunning.value)

        tileScope.launch {
            EventBus.isServiceRunning.collectLatest { isRunning ->
                updateTileState(isRunning)
            }
        }
    }

    override fun onStopListening() {
        super.onStopListening()
        tileScope.cancel()
    }

    override fun onClick() {
        super.onClick()
        val isCurrentlyRunning = EventBus.isServiceRunning.value

        if (isCurrentlyRunning) {
            // Hentikan service
            val stopIntent = Intent(this, CameraForegroundService::class.java).apply {
                action = CameraForegroundService.ACTION_STOP_SERVICE
            }
            startService(stopIntent)
            updateTileState(false)
        } else {
            // Karena Android 11+ melarang memulai foreground service camera dari latar belakang,
            // kita arahkan pengguna membuka MainActivity jika belum aktif
            val launchIntent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                // Android 14+ pending intent launcher
                startActivityAndCollapse(
                    android.app.PendingIntent.getActivity(
                        this,
                        0,
                        launchIntent,
                        android.app.PendingIntent.FLAG_IMMUTABLE
                    )
                )
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(launchIntent)
            }
        }
    }

    private fun updateTileState(isRunning: Boolean) {
        val tile = qsTile ?: return
        tile.state = if (isRunning) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = if (isRunning) "BlinkScroll: Aktif" else "BlinkScroll: Mati"
        tile.updateTile()
    }
}
