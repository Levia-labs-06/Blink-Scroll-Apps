package com.blinkscroll.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.blinkscroll.app.MainActivity
import com.blinkscroll.app.R
import com.blinkscroll.app.data.PreferencesRepository
import com.blinkscroll.app.detector.BlinkDetector
import com.blinkscroll.app.model.CalibrationTelemetry
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarkerResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Foreground Service bertipe "camera" yang mengoperasikan CameraX ImageAnalysis
 * dan Google MediaPipe Face Landmarker di latar belakang.
 */
class CameraForegroundService : LifecycleService() {

    companion object {
        private const val TAG = "CameraService"
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "blink_scroll_channel"
        const val ACTION_STOP_SERVICE = "com.blinkscroll.app.ACTION_STOP"
    }

    private lateinit var cameraExecutor: ExecutorService
    private var faceLandmarker: FaceLandmarker? = null
    private val blinkDetector = BlinkDetector()
    private lateinit var preferencesRepo: PreferencesRepository

    private var cameraProvider: ProcessCameraProvider? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var isCameraPausedByScreen = false
    private var retryJob: Job? = null

    // Perhitungan FPS telemetri
    private var frameCount = 0
    private var lastFpsTimestamp = System.currentTimeMillis()
    private var currentFps = 0f

    // Receiver untuk mendeteksi layar mati (ACTION_SCREEN_OFF) & hidup (ACTION_USER_PRESENT)
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    Log.d(TAG, "Layar mati: Pause kamera untuk menghemat daya baterai")
                    pauseCamera()
                }
                Intent.ACTION_USER_PRESENT -> {
                    Log.d(TAG, "Layar aktif kembali: Resume kamera")
                    resumeCamera()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        preferencesRepo = PreferencesRepository(applicationContext)
        cameraExecutor = Executors.newSingleThreadExecutor()

        // Ambil WakeLock sebagian untuk menjaga pemrosesan saat layar aktif
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "BlinkScroll:CameraWakeLock")

        // Daftarkan listener perubahan pengaturan secara real-time tanpa restart service
        lifecycleScope.launch {
            preferencesRepo.settingsFlow.collect { newSettings ->
                blinkDetector.settings = newSettings
                Log.d(TAG, "Pengaturan detector diperbarui: close=${newSettings.closeThreshold}")
            }
        }

        // Daftarkan broadcast receiver layar mati/hidup
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        registerReceiver(screenReceiver, filter)

        setupMediaPipe()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        if (intent?.action == ACTION_STOP_SERVICE) {
            Log.d(TAG, "Menerima aksi Berhenti dari notifikasi")
            stopSelf()
            return START_NOT_STICKY
        }

        startForegroundServiceWithNotification()
        EventBus.setServiceRunning(true)
        startCamera()

        return START_STICKY
    }

    private fun startForegroundServiceWithNotification() {
        createNotificationChannel()

        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            notificationIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, CameraForegroundService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_content))
            .setSmallIcon(R.drawable.ic_tile_blink)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                getString(R.string.notification_action_stop),
                stopPendingIntent
            )
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    /**
     * Inisialisasi MediaPipe FaceLandmarker dengan blendshapes aktif dalam mode LIVE_STREAM.
     */
    private fun setupMediaPipe() {
        try {
            val baseOptions = BaseOptions.builder()
                .setModelAssetPath("face_landmarker.task")
                .build()

            val options = FaceLandmarker.FaceLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumFaces(1)
                .setOutputFaceBlendshapes(true)
                .setOutputFacialTransformationMatrixes(false)
                .setResultListener { result: FaceLandmarkerResult, _: MPImage ->
                    handleFaceLandmarkerResult(result)
                }
                .setErrorListener { error ->
                    Log.e(TAG, "MediaPipe Error: ${error.message}")
                }
                .build()

            faceLandmarker = FaceLandmarker.createFromOptions(this, options)
            Log.d(TAG, "MediaPipe FaceLandmarker berhasil diinisialisasi")
        } catch (e: Exception) {
            Log.e(TAG, "Gagal menginisialisasi MediaPipe FaceLandmarker: ${e.message}", e)
        }
    }

    /**
     * Menghubungkan CameraX ImageAnalysis dengan kamera depan.
     * Resolusi 320x240, STRATEGY_KEEP_ONLY_LATEST untuk latensi minimum dan hemat baterai.
     */
    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            try {
                cameraProvider = cameraProviderFuture.get()

                val imageAnalysis = ImageAnalysis.Builder()
                    .setTargetResolution(Size(320, 240))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()

                imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                    processImageProxy(imageProxy)
                }

                val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA

                cameraProvider?.unbindAll()
                cameraProvider?.bindToLifecycle(
                    this,
                    cameraSelector,
                    imageAnalysis
                )

                wakeLock?.acquire(10 * 60 * 1000L /*10 min timeout*/)
                Log.d(TAG, "CameraX berhasil di-bind ke kamera depan")
            } catch (e: Exception) {
                Log.e(TAG, "Gagal mengaktifkan kamera depan: ${e.message}", e)
                scheduleCameraRetry()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    /**
     * Mengonversi ImageProxy ke MPImage dan mengirimkannya ke MediaPipe.
     * ImageProxy WAJIB ditutup di blok finally untuk mencegah memory leak CameraX!
     */
    private fun processImageProxy(imageProxy: ImageProxy) {
        try {
            val bitmap = imageProxy.toBitmap()
            val mpImage = BitmapImageBuilder(bitmap).build()
            val timestampMs = System.currentTimeMillis()

            // Hitung frame rate telemetri
            frameCount++
            if (timestampMs - lastFpsTimestamp >= 1000L) {
                currentFps = frameCount * 1000f / (timestampMs - lastFpsTimestamp)
                frameCount = 0
                lastFpsTimestamp = timestampMs
            }

            // Kirim frame ke MediaPipe secara asinkron
            faceLandmarker?.detectAsync(mpImage, timestampMs)
        } catch (e: Exception) {
            Log.e(TAG, "Error saat memproses ImageProxy: ${e.message}")
        } finally {
            // Wajib selalu ditutup agar CameraX tidak macet / memory leak
            imageProxy.close()
        }
    }

    /**
     * Memproses hasil blendshapes dari MediaPipe:
     * Mencari kategori blendshape 'eyeBlinkLeft' dan 'eyeBlinkRight'.
     */
    private fun handleFaceLandmarkerResult(result: FaceLandmarkerResult) {
        val blendshapesList = result.faceBlendshapes()

        if (blendshapesList.isPresent && blendshapesList.get().isNotEmpty()) {
            val blendshapes = blendshapesList.get()[0].elements()

            var leftBlink = 0f
            var rightBlink = 0f

            for (category in blendshapes) {
                when (category.categoryName()) {
                    "eyeBlinkLeft" -> leftBlink = category.score()
                    "eyeBlinkRight" -> rightBlink = category.score()
                }
            }

            val avgScore = (leftBlink + rightBlink) / 2f
            val event = blinkDetector.processFrame(leftBlink, rightBlink)

            // Update telemetri untuk layar kalibrasi di MainActivity
            val telemetry = CalibrationTelemetry(
                leftBlinkScore = leftBlink,
                rightBlinkScore = rightBlink,
                averageScore = avgScore,
                isEyesClosed = blinkDetector.isEyesClosed(),
                faceDetected = true,
                fps = currentFps,
                lastEvent = event
            )
            EventBus.updateTelemetry(telemetry)

            // Jika ada event kedipan sengaja terdeteksi, kirim ke EventBus
            if (event != null) {
                Log.d(TAG, "Deteksi Event: ${event.action} (${event.durationMs} ms)")
                EventBus.tryEmitBlinkEvent(event)
            }
        } else {
            // Wajah tidak terdeteksi pada frame ini
            blinkDetector.checkFaceTimeout()
            EventBus.updateTelemetry(
                EventBus.telemetry.value.copy(
                    faceDetected = false,
                    isEyesClosed = false,
                    fps = currentFps
                )
            )
        }
    }

    private fun pauseCamera() {
        if (!isCameraPausedByScreen) {
            isCameraPausedByScreen = true
            cameraProvider?.unbindAll()
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
            Log.d(TAG, "Kamera dihentikan sementara")
        }
    }

    private fun resumeCamera() {
        if (isCameraPausedByScreen) {
            isCameraPausedByScreen = false
            startCamera()
            Log.d(TAG, "Kamera dilanjutkan kembali")
        }
    }

    /**
     * Mekanisme auto-retry setiap 3 detik jika kamera direbut aplikasi lain (misal video call).
     */
    private fun scheduleCameraRetry() {
        retryJob?.cancel()
        retryJob = lifecycleScope.launch(Dispatchers.Main) {
            delay(3000L)
            Log.d(TAG, "Mencoba mengaktifkan kembali kamera yang sempat terputus...")
            startCamera()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Menghancurkan CameraForegroundService")
        EventBus.setServiceRunning(false)

        try {
            unregisterReceiver(screenReceiver)
        } catch (_: Exception) {}

        retryJob?.cancel()
        cameraProvider?.unbindAll()

        // Bebaskan resource MediaPipe dan Executor untuk mencegah memory leak
        faceLandmarker?.close()
        faceLandmarker = null
        cameraExecutor.shutdown()

        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
        }
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }
}
