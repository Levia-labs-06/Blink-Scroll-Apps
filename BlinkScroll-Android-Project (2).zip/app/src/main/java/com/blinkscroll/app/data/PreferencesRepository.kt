package com.blinkscroll.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "blink_scroll_settings")

/**
 * Data class konfigurasi detektor kedipan dan parameter gesture scroll.
 */
data class BlinkSettings(
    val closeThreshold: Float = 0.60f,       // Ambang batas menutup mata (0.4 - 0.8)
    val openThreshold: Float = 0.35f,        // Ambang batas membuka mata (histeresis)
    val minLongBlinkMs: Long = 500L,         // Durasi minimum kedip panjang (400 - 900 ms)
    val maxLongBlinkMs: Long = 1400L,        // Batas atas kedip panjang
    val doubleBlinkWindowMs: Long = 600L,    // Jendela waktu maksimum antar 2 kedipan (ms)
    val scrollDistancePercent: Int = 40,     // Persentase swipe vertikal dari tinggi layar (25% - 60%)
    val cooldownMs: Long = 800L,             // Cooldown jeda antar aksi (500 - 2000 ms)
    val autoStopMinutes: Int = 30            // Waktu mati otomatis jika tanpa aksi (menit)
)

/**
 * Repository pengelola pengaturan aplikasi berbasis DataStore Preferences.
 */
class PreferencesRepository(private val context: Context) {

    companion object {
        private val KEY_CLOSE_THRESHOLD = floatPreferencesKey("close_threshold")
        private val KEY_OPEN_THRESHOLD = floatPreferencesKey("open_threshold")
        private val KEY_MIN_LONG_BLINK = longPreferencesKey("min_long_blink_ms")
        private val KEY_SCROLL_PERCENT = intPreferencesKey("scroll_percent")
        private val KEY_COOLDOWN_MS = longPreferencesKey("cooldown_ms")
        private val KEY_AUTO_STOP_MIN = intPreferencesKey("auto_stop_min")
    }

    val settingsFlow: Flow<BlinkSettings> = context.dataStore.data.map { preferences ->
        val closeThresh = preferences[KEY_CLOSE_THRESHOLD] ?: 0.60f
        // Jaga histeresis: open threshold selalu proporsional lebih rendah dari close threshold
        val openThresh = preferences[KEY_OPEN_THRESHOLD] ?: (closeThresh * 0.58f).coerceIn(0.20f, 0.45f)
        val minLong = preferences[KEY_MIN_LONG_BLINK] ?: 500L
        val scrollDist = preferences[KEY_SCROLL_PERCENT] ?: 40
        val cooldown = preferences[KEY_COOLDOWN_MS] ?: 800L
        val autoStop = preferences[KEY_AUTO_STOP_MIN] ?: 30

        BlinkSettings(
            closeThreshold = closeThresh,
            openThreshold = openThresh,
            minLongBlinkMs = minLong,
            scrollDistancePercent = scrollDist,
            cooldownMs = cooldown,
            autoStopMinutes = autoStop
        )
    }

    suspend fun updateCloseThreshold(value: Float) {
        context.dataStore.edit { preferences ->
            preferences[KEY_CLOSE_THRESHOLD] = value.coerceIn(0.40f, 0.80f)
            preferences[KEY_OPEN_THRESHOLD] = (value * 0.58f).coerceIn(0.20f, 0.45f)
        }
    }

    suspend fun updateMinLongBlink(durationMs: Long) {
        context.dataStore.edit { preferences ->
            preferences[KEY_MIN_LONG_BLINK] = durationMs.coerceIn(400L, 900L)
        }
    }

    suspend fun updateScrollDistancePercent(percent: Int) {
        context.dataStore.edit { preferences ->
            preferences[KEY_SCROLL_PERCENT] = percent.coerceIn(25, 60)
        }
    }

    suspend fun updateCooldownMs(cooldownMs: Long) {
        context.dataStore.edit { preferences ->
            preferences[KEY_COOLDOWN_MS] = cooldownMs.coerceIn(500L, 2000L)
        }
    }

    suspend fun updateAutoStopMinutes(minutes: Int) {
        context.dataStore.edit { preferences ->
            preferences[KEY_AUTO_STOP_MIN] = minutes.coerceIn(5, 120)
        }
    }
}
