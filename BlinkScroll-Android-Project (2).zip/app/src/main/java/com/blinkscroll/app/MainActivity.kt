package com.blinkscroll.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.blinkscroll.app.data.BlinkSettings
import com.blinkscroll.app.data.PreferencesRepository
import com.blinkscroll.app.model.CalibrationTelemetry
import com.blinkscroll.app.service.CameraForegroundService
import com.blinkscroll.app.service.EventBus
import com.blinkscroll.app.ui.screens.AboutScreen
import com.blinkscroll.app.ui.screens.CalibrationScreen
import com.blinkscroll.app.ui.screens.HomeScreen
import com.blinkscroll.app.ui.screens.SettingsScreen
import com.blinkscroll.app.ui.theme.BlinkScrollTheme
import kotlinx.coroutines.launch

/**
 * Menu navigasi bawah pada aplikasi BlinkScroll.
 */
enum class AppScreen(val title: String, val icon: ImageVector) {
    HOME("Beranda", Icons.Default.Home),
    CALIBRATION("Kalibrasi", Icons.Default.Tune),
    SETTINGS("Pengaturan", Icons.Default.Settings),
    ABOUT("Tentang", Icons.Default.Info)
}

class MainActivity : ComponentActivity() {

    private lateinit var preferencesRepo: PreferencesRepository

    // State izin
    private var hasCameraPermission by mutableStateOf(false)
    private var hasNotificationPermission by mutableStateOf(false)
    private var hasAccessibilityPermission by mutableStateOf(false)

    // Launcher Izin Kamera
    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
        if (!granted) {
            Toast.makeText(this, "Izin kamera diperlukan untuk mendeteksi kedipan mata", Toast.LENGTH_LONG).show()
        }
    }

    // Launcher Izin Notifikasi (Android 13+)
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasNotificationPermission = granted
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferencesRepo = PreferencesRepository(applicationContext)

        setContent {
            BlinkScrollTheme {
                val isServiceRunning by EventBus.isServiceRunning.collectAsState()
                val telemetry by EventBus.telemetry.collectAsState()
                val settings by preferencesRepo.settingsFlow.collectAsState(initial = BlinkSettings())

                var currentScreen by remember { mutableStateOf(AppScreen.HOME) }

                Scaffold(
                    bottomBar = {
                        NavigationBar {
                            AppScreen.entries.forEach { screen ->
                                NavigationBarItem(
                                    selected = currentScreen == screen,
                                    onClick = { currentScreen = screen },
                                    icon = { Icon(screen.icon, contentDescription = screen.title) },
                                    label = { Text(screen.title) }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    when (currentScreen) {
                        AppScreen.HOME -> HomeScreen(
                            isServiceRunning = isServiceRunning,
                            hasCameraPermission = hasCameraPermission,
                            hasNotificationPermission = hasNotificationPermission,
                            hasAccessibilityPermission = hasAccessibilityPermission,
                            onRequestCamera = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) },
                            onRequestNotification = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                            },
                            onOpenAccessibilitySettings = { openAccessibilitySettings() },
                            onToggleService = { toggleForegroundService() },
                            onNavigateCalibration = { currentScreen = AppScreen.CALIBRATION },
                            modifier = Modifier.padding(innerPadding)
                        )

                        AppScreen.CALIBRATION -> CalibrationScreen(
                            telemetry = telemetry,
                            settings = settings,
                            isServiceRunning = isServiceRunning,
                            modifier = Modifier.padding(innerPadding)
                        )

                        AppScreen.SETTINGS -> SettingsScreen(
                            settings = settings,
                            onUpdateCloseThreshold = { value ->
                                lifecycleScope.launch { preferencesRepo.updateCloseThreshold(value) }
                            },
                            onUpdateMinLongBlink = { ms ->
                                lifecycleScope.launch { preferencesRepo.updateMinLongBlink(ms) }
                            },
                            onUpdateScrollDistance = { percent ->
                                lifecycleScope.launch { preferencesRepo.updateScrollDistancePercent(percent) }
                            },
                            onUpdateCooldown = { ms ->
                                lifecycleScope.launch { preferencesRepo.updateCooldownMs(ms) }
                            },
                            onUpdateAutoStop = { min ->
                                lifecycleScope.launch { preferencesRepo.updateAutoStopMinutes(min) }
                            },
                            modifier = Modifier.padding(innerPadding)
                        )

                        AppScreen.ABOUT -> AboutScreen(
                            modifier = Modifier.padding(innerPadding)
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        checkPermissions()
    }

    private fun checkPermissions() {
        hasCameraPermission = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        hasNotificationPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

        hasAccessibilityPermission = isAccessibilityServiceEnabled(this)
    }

    /**
     * Memeriksa apakah ScrollAccessibilityService pengguna sudah dinyalakan di Pengaturan Sistem.
     */
    private fun isAccessibilityServiceEnabled(context: Context): Boolean {
        val expectedServiceName = "${context.packageName}/com.blinkscroll.app.service.ScrollAccessibilityService"
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        return enabledServices.split(':').any { it.equals(expectedServiceName, ignoreCase = true) }
    }

    private fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(intent)
        Toast.makeText(
            this,
            "Cari dan aktifkan 'BlinkScroll — Layanan Scroll Otomatis'",
            Toast.LENGTH_LONG
        ).show()
    }

    /**
     * Memulai atau menghentikan CameraForegroundService.
     * Sesuai ketentuan Android 11+, foreground service camera hanya boleh dimulai saat aplikasi sedang terlihat di layar.
     */
    private fun toggleForegroundService() {
        val serviceIntent = Intent(this, CameraForegroundService::class.java)

        if (EventBus.isServiceRunning.value) {
            stopService(serviceIntent)
            Toast.makeText(this, "Layanan BlinkScroll dihentikan", Toast.LENGTH_SHORT).show()
        } else {
            ContextCompat.startForegroundService(this, serviceIntent)
            Toast.makeText(this, "Layanan BlinkScroll berhasil dimulai", Toast.LENGTH_SHORT).show()
        }
    }
}
