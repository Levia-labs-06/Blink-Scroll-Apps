Unduh model face_landmarker.task dari MediaPipe:
https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task
dan letakkan di direktori ini (app/src/main/assets/face_landmarker.task).