package com.blinkscroll.app

import com.blinkscroll.app.data.BlinkSettings
import com.blinkscroll.app.detector.BlinkDetector
import com.blinkscroll.app.model.BlinkAction
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test

/**
 * Unit Test untuk memastikan ketepatan algoritma state machine BlinkDetector.
 */
class BlinkDetectorTest {

    private lateinit var detector: BlinkDetector

    @Before
    fun setUp() {
        val settings = BlinkSettings(
            closeThreshold = 0.60f,
            openThreshold = 0.35f,
            minLongBlinkMs = 500L,
            maxLongBlinkMs = 1400L,
            doubleBlinkWindowMs = 600L,
            cooldownMs = 800L
        )
        detector = BlinkDetector(settings)
    }

    @Test
    fun testNaturalBlinkIsIgnored() {
        // Kedipan mata alami biasanya berdurasi 150 - 250 ms
        var t = 1000L

        // Mata terbuka
        var event = detector.processFrame(0.1f, 0.1f, t)
        assertNull(event)

        // Mata mulai tertutup (skor >= 0.6)
        t += 30L
        event = detector.processFrame(0.7f, 0.7f, t)
        assertNull(event)

        // Mata terbuka kembali setelah 200 ms (durasi = 200 ms -> kedip alami)
        t += 200L
        event = detector.processFrame(0.1f, 0.1f, t)

        // Kedipan alami harus diabaikan (null)
        assertNull("Kedipan alami 200 ms harus diabaikan", event)
    }

    @Test
    fun testLongBlinkTriggersScrollDown() {
        var t = 2000L

        // 1. Mata terbuka
        detector.processFrame(0.1f, 0.1f, t)

        // 2. Mata menutup sengaja
        t += 50L
        detector.processFrame(0.85f, 0.85f, t)

        // 3. Tahan tutup selama 650 ms (melebihi minLongBlinkMs = 500 ms)
        t += 650L
        val event = detector.processFrame(0.2f, 0.2f, t)

        assertNotNull("Harus memicu BlinkEvent", event)
        assertEquals(BlinkAction.LONG_BLINK, event?.action)
        assertEquals(650L, event?.durationMs)
    }

    @Test
    fun testDoubleBlinkTriggersScrollUp() {
        var t = 5000L

        // Kedipan Cepat Pertama (durasi 150 ms)
        detector.processFrame(0.8f, 0.8f, t)
        t += 150L
        val firstBlinkResult = detector.processFrame(0.2f, 0.2f, t)
        assertNull("Kedipan pertama belum memicu event", firstBlinkResult)

        // Jeda antar kedipan 250 ms (di bawah batas doubleBlinkWindowMs = 600 ms)
        t += 250L

        // Kedipan Cepat Kedua (durasi 160 ms)
        detector.processFrame(0.85f, 0.85f, t)
        t += 160L
        val secondBlinkResult = detector.processFrame(0.2f, 0.2f, t)

        assertNotNull("Dua kedipan cepat harus memicu DOUBLE_BLINK", secondBlinkResult)
        assertEquals(BlinkAction.DOUBLE_BLINK, secondBlinkResult?.action)
    }

    @Test
    fun testCooldownPreventsSpam() {
        var t = 10000L

        // Trigger Long Blink pertama
        detector.processFrame(0.8f, 0.8f, t)
        t += 600L
        val firstEvent = detector.processFrame(0.2f, 0.2f, t)
        assertNotNull(firstEvent)

        // Percobaan kedip berikutnya terjadi 300 ms setelah aksi pertama (masih dalam cooldown 800 ms)
        t += 300L
        detector.processFrame(0.8f, 0.8f, t)
        t += 550L
        val cooldownEvent = detector.processFrame(0.2f, 0.2f, t)

        assertNull("Event dalam masa cooldown 800 ms harus ditolak", cooldownEvent)
    }
}
